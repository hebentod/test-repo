// Get the "Create an Account" button
var createAccountBtn = document.getElementById("createAccountBtn");

// Get the modal or "Create an Account" section
var createAccountModal = document.getElementById("createAccountModal");

// Add event listener to the button
createAccountBtn.addEventListener("click", function() {

    if (createAccountModal.style.display === "none") {
        createAccountModal.style.display = "block";
    } else {
        createAccountModal.style.display = "none";
    }
});
